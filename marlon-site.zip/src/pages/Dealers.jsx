import React from "react";
import Dealer from "../components/Dealer/Dealer";

export default function Dealers() {
  return (
    <div>
      <Dealer />
    </div>
  );
}
